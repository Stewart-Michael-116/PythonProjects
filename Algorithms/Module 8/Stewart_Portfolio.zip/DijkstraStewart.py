# Dijkstra's Algorithm
# Relax edges until you find the vertex
# Based on code from lesson and examples from Divyanshu Mehta
# https://www.geeksforgeeks.org/python-program-for-dijkstras-shortest-path-algorithm-greedy-algo-7/ 
import random
import time
import sys
from timeit import default_timer as timer

class Graph():
 
    def __init__(self, vertices):
        self.graphVertex = vertices
        self.graph = [[0 for column in range(vertices)]
                      for row in range(vertices)]
 
    def printSolution(self, dist):
        print("Vertex \t Distance from Source")
        for node in range(self.graphVertex):
            print(node, "\t\t", dist[node])
 
    def minDistance(self, dist, sptSet):
 
        min = 1e7
 
        for v in range(self.graphVertex):
            if dist[v] < min and sptSet[v] == False:
                min = dist[v]
                min_index = v
 
        return min_index
 
    def dijkstra(self, src):
 
        dist = [1e7] * self.graphVertex
        dist[src] = 0
        sptSet = [False] * self.graphVertex
 
        for cout in range(self.graphVertex):
 
            u = self.minDistance(dist, sptSet)

            sptSet[u] = True

            for v in range(self.graphVertex):
                if (self.graph[u][v] > 0 and
                   sptSet[v] == False and
                   dist[v] > dist[u] + self.graph[u][v]):
                    dist[v] = dist[u] + self.graph[u][v]
 
        #self.printSolution(dist)
 
g = Graph(9)
# Graph example
g.graph = [[0, 4, 0, 0, 0, 0, 0, 8, 0],
           [4, 0, 8, 0, 0, 0, 0, 11, 0],
           [0, 8, 0, 7, 0, 4, 0, 0, 2],
           [0, 0, 7, 0, 9, 14, 0, 0, 0],
           [0, 0, 0, 9, 0, 10, 0, 0, 0],
           [0, 0, 4, 14, 10, 0, 2, 0, 0],
           [0, 0, 0, 0, 0, 2, 0, 1, 6],
           [8, 11, 0, 0, 0, 0, 1, 0, 7],
           [0, 0, 2, 0, 0, 0, 6, 7, 0]
           ]

sum = 0

for i in range(10):
    start = float(timer())
    g.dijkstra(0)
    end = float(timer())
    sum = sum + (end-start)

print(sum)