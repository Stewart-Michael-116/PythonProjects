# Software Engineer Class Def
class softwareEngineerTraits:
    def __init__(self, trait1, trait2, trait3):
        self.trait1 = trait1
        self.trait2 = trait2
        self.trait3 = trait3
# Initialize Engineer Class Def
trait1 = "\nEfficient Learning:\nSoftware engineers have\
spent a large portion of their\
life learning new technologies.\
This means that they know\
strategies for learning that work\
best for them in order to\
adapt to technology quickly.\n"
trait2 = "\nSystems Thinking\nSoftware engineers commonly\
analyze large structures and\
architectures. This means that \
decisions that software engineers\
make commonly take into account \
the effects on the other\
parts of the system.\n"
trait3 = "\nContent with being wrong\nSoftware engineers make\
decisions on a very consisten\
basis. This means that they have\
been wrong in a large amount of \
situations. They commonly realize\
that being wrong is not a scary thing,\
but it is important to seek the\
truth for the betterment of \
the company and other engineers.\n"

engineerObject = softwareEngineerTraits(trait1, trait2, trait3)

# Loop with user input
while True:
    userInput = input("Please enter a number 1-3 or exit to learn more about common personality traits of software engineers!\n")
    if userInput == "1":
        #do
        print(engineerObject.trait1)
    elif userInput == "2":
        print(engineerObject.trait2)
    elif userInput == "3":
        print(engineerObject.trait3)
    elif userInput == "exit":
        break
    else:
        print("Invalid Input\n")