# Create Class
class listObject:
    def __init__(self, list_name,item):
        self.item = item
        self.ListName = list_name

# Make blank list
list_list = []

# Print out 
while True:
    user_input = input("\nWould you like to add or view to list?\n")
    if user_input == "add":
        user_add_list = input("Please add name of list\n")
        user_add_item = input("Please name an item in this list\n")
        list_list.append(listObject(user_add_list,user_add_item))
    elif user_input == "view":
        print("\n")
        for x in list_list:

            print(x.ListName)
            
            print(x.item)
        print("These are all of the lists added to the app, the screens the user can access include the main page and these list pages.") 
        print("The number of pages is {}".format(len(list_list)+1))
        print("The flow of the pages revolves around the main page, the user can go to each custom list and then back to the main page.")
    else:
        break